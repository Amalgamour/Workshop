# 05 — Correlate persisted bridge receipts
version: 001
Authorization: draft — 2026-10-27
who: Codex Prime
state: returned
Face: 05
PPPP: 0504
book: 00.00.10.work
keyword: app-entry

## Assignment
Executor: Grok Builder 1. Acceptance: Codex Prime.
Release: released by the Director, 2026-10-27.
Claim: Grok 4.7 (xAI), session 01a179d2-387a-7661-8702-6e53f95e96b5, 2026-10-27, HEAD 54274e698dde1c6cbd5e25177395c62c2a2c645a.
Reviewed base: 54274e698dde1c6cbd5e25177395c62c2a2c645a, branch workshop.
Repair stored-receipt correlation and the documented pass 03 test timing. Preserve the working fixture exchange.
The packed page is `evidence/05.06/packed/05.06.md`, sha256 `8365ec5ebe811d34bb61f81d5ce8b46a212fbf3b1dd334a1a6d81d7607b65805`, 3937 bytes.

Director, verbatim:

> Read and execute:
> D:\Git\lib-build\00.kernel\00.00.10.work\0504.app-entry\05.06.md
>
> I release this batch.
>
> Repair stored-receipt correlation and address the test-timing
> issue within the stated scope. Preserve the working exchange.
>
> Return on that page for Codex Prime review.
> Preserve the Clerk and SoF lanes. No activation or model calls.

## Return — Grok Builder 1

Did. Status, replay, and recover now refuse a stored receipt that is not one strict JSON object of schema `worker-bridge/receipt@1`, or whose `delivery_id`, `job_id`, `backend`, or `request_sha256` does not match the requested delivery, the stored request, and the provenance. A missing request hash is not a wildcard. A correct hash does not excuse different ids. The Prime probe's fresh-process status now exits 2 and leaves the tampered receipt bytes in place. The pass 03 test budget lets the direct child start and still fails the reviewed five-second blockage. The working exchange still collects, reads, and replays.

Blocked. Real model calls, Clerk integration, SoF, activation, seating, and a main merge stay outside this release. A file symlink could not be created here (`WinError 1314`). Same-user Python is not sandboxed. There is no exactly-once promise. Collection is not approval. Root `README.md` is outside this pack's edit list, so it still says the lab is unchanged and that BRI-01 blocks acceptance.

Need. Codex Prime review of this page. The bounded next step is that review. No activation and no Clerk integration follow from this return.

## #01 — Notes and pins
Notes are `06.06.md`, sha256 `8b6f6498b7fef8e4eb3706d7080bab4d6ed851c1a3af8efbe0e8b9ee019655d3`, 7251 bytes. They were written after the pack and Prime's 05.05 review were read, and before the glue was edited. The outcome section was added after the suites.

`evidence/pack05.06/source-manifest.tsv` matched the live bytes at claim, 6 rows, 0 bad. That directory was already on the claim commit. It was not rewritten. `context.py` stays `5b1a31d47bb9f9b465a8492541467abbd9bd3a99ae524be7aa0dbffe2380eb9f`, 22063 bytes. `app/development-workspace.json` stays `b6f4e13b3157416a05b102dfe8a01605e007c2608ba6b0fd06987757d2e33018`, 538 bytes. `app/librarian.py` stays `24e510dbf8c55c315af1d8b6777a9f5a645abe79528967d8ef24954e916a651c`, 5909 bytes. `app/worker-bridge.json` stays `94dd3c4770d77f30482f75086d6ebc58335eb51b4a8641c86dcc6d55ce4385ea`, 1136 bytes. The eight lab runtime pins are unchanged. `adapter.py` stays `27d683b494c13bd120d5099f863bb68ab96c6d458dd2a7641c0129122b89c9de`, 17038 bytes. `_driver_pass03.py` stays `d8554aa880b923d2c6963f5b7c509b890e73440623a1b8b97a2ec80d8ed329ff`, 1417 bytes.

Clerk `0506.clerk-handoff` was already on the claim commit and was not edited. SoF is a separate repository and is not in this tree.

## #02 — One receipt check
`_require_stored_receipt` is the only identity check. `_read_stored_receipt` uses it on the file before status, replay, or recover asks the adapter to report that file. `_guard_reported_receipt` uses it again on the object about to be printed, when a receipt file exists. A missing file is left to the adapter. `unknown`, `accepted-not-launched`, and `uncertain` do not have to carry receipt fields.

A persisted receipt must be a strict JSON object with schema `worker-bridge/receipt@1`. `delivery_id`, `job_id`, `backend`, and `request_sha256` must be non-empty strings. `delivery_id` must equal the requested delivery, the provenance, and the stored request. `job_id` and `backend` must equal the provenance and the stored request. `request_sha256` must equal the provenance hash. Extra keys, including `artifacts`, `cleanup`, `recovered`, and `replayed`, stay allowed. The refusal is `stop:` on stderr, empty stdout, and exit 2. It does not rewrite the receipt and it does not launch. This is not a signature, an approval, or a second ledger. Status remains read-only.

## #03 — Probe, suites, and the test budget
Before the repair, a real `bridge-test` was followed by removing `request_sha256` and setting `delivery_id` to `another-delivery` and `job_id` to `another-job`. Fresh-process `bridge-status` exited 0 and printed `collection: collected`. The tampered receipt was 1011 bytes, sha256 `171409fc0f719c58590871c717f4011186dc5d722493452ca5dca731ab5596bf`. Stdout is `evidence/05.06/probe-before/bridge-status.stdout.txt`, sha256 `f9cb10ba3b134e3762bb770600667551974710f54599b6540eeb80e17a64eadb`, 425 bytes. Stderr was empty.

After the repair, the same steps exited 2. Stderr was `stop: stored receipt field is missing: request_sha256` (`evidence/05.06/probe-after/bridge-status.stderr.txt`, sha256 `c00daad88336642247c8745a71df0537d5dbcc5c6962c98137aecc1f6c856f81`, 54 bytes). Stdout was empty. The tampered receipt stayed 1011 bytes, sha256 `002bd2a46a5b574a357e625bbde6822a9794c4dc0e131e6d02fbbe6f3347d41b`. `launches.log` was unchanged. The two tamper hashes differ because each run's original receipt contains that run's absolute paths.

The integration suite also refuses a correct request hash with wrong ids, an unsupported schema, a non-object receipt, and malformed JSON, on status, replay, and recover. Those refusals leave the receipt, the request, and `launches.log` unchanged. A restored consistent receipt still reads and replays with one launch. Unknown, accepted-not-launched, interrupted, and current-work changes still behave as before.

`app/tests/test_worker_bridge.py` was run twice. Both exited 0: pass 38, expected-refusal 27, skip 1, fail 0. The kept log is the second run, `evidence/05.06/bridge-test-log.txt`, sha256 `615c82b7fc5f26b1d3e7a17b2a492d269492b81f3a4021faf5d6cf4f25b40935`, 35877 bytes. The first run's log was removed when `app/tests/test_entry.py` cleared `app/scratch`. The skip is the dangling file symlink, `WinError 1314`. The same run copied the lab and passed its 30 tests. Pass 03's two tests took 10.511 seconds inside that copy.

`app/tests/test_entry.py` exited 0: pass 12, expected-refusal 46, skip 1, fail 0. Log `evidence/05.06/entry-test-log.txt`, sha256 `32c532b49dfc30ca655995e63d2f679f3de0bc9923f1916b80a2f97c178e3bb2`, 27938 bytes.

`tests/test_pass03.py` now uses `TIMEOUT_S` 1.5, outer slack 1.0, and bound 4.5. Cleanup stays 2.0. The bound is under the reviewed 5.078 second blockage, so that old wait would still fail. A `timeout` result is still not accepted as incomplete output. The before bytes are `evidence/pass04/source-before/tests/test_pass03.py`, sha256 `a89927ee37821c1021bf30b3d4908be56bb076052aa6d33661ec8a555302f339`, 4595 bytes. The after file is `03ffc50a67c7323536c0c46d7f82c5f76cf02a33d44f4264665002d6005140d8`, 5272 bytes. An isolated run of those two tests exited 0 in 13.181 seconds. The first calls returned `incomplete-output`, `collection: not attempted`, cleanup not complete, and retained `stdout reader` and `stderr reader`, at 3.516 and 3.531 seconds. The replay was `replayed: true` at 0.0 seconds. The manifest is `labs/worker-bridge-pass01/evidence/pass04/SHA256SUMS.pass04.txt`, sha256 `3e81d54b8c111e7bb4a8110e73df078c79492acc205d9b8b5f4544d43ab11eb5`, 1082 bytes, 10 rows. The reason is `evidence/pass04/bound.md`.

Changed source: `app/worker_bridge.py` `657a4dfcd72dcd040a12d506ba5e2b6f7a50a8d7bd38364d42753e7b48bdd975` (34227 bytes). `app/tests/test_worker_bridge.py` `e89e73995e3a97d79e51f48dc44da6fa151e4168ce1163ef44cebdcdad2a0fd8` (44208 bytes). `app/README.md` `f57ff8b523dbdd7fdc6cc19da9ee34dc611a5cef1aed5a01b544726384ca6cbf` (6930 bytes).

## #04 — Custody and limits
The assignment record was hand-edited from waiting to running, then to returned. Clerk did not make that transition. `00.live.md` was regenerated with `render_live.py`. The renderer was not edited. `render_live.py check` printed `check: 00.kernel/00.live.md matches the record` (`evidence/05.06/render-check.txt`, sha256 `0cb6ad63c6a61988153304a55d3d7619a74207942f44328a35b8b9b12137cc3c`, 47 bytes).

Assignment bytes: before `evidence/05.06/assignment-before.md` sha256 `1ee161c5497212eccfcc13d6703e94df7b8c05d31e1dae00e978ac321d7978bc`, 560 bytes. Running `evidence/05.06/assignment-running.md` sha256 `67a85eb7545107a0c75176304e587d235f93ba79cb893b97ed3b33f465d9ea83`, 496 bytes. Returned record sha256 `11f0478f542c2970729adae749d97dd109144601f0e3d104e7f35e41a4e11a9c`, 467 bytes. Views: before `evidence/05.06/live-before.md` sha256 `4b576f50b99b3d861c69ea82004b4ddce4390a6ae04476443457626d6c5a65bb`, 1175 bytes; running `evidence/05.06/live-running.md` sha256 `d7e964e605b81d14fa52a6053035debcfc53ca3ee3801cb5c679ca0db1a7d76e`, 1111 bytes; current `00.live.md` sha256 `935b09b8e168115c1e222c4f1454286aead7add8df6360b98b9a5acf071511f4`, 1082 bytes.

`where` and `validate` on the returned workspace printed desk `00.kernel`, work book `00.00.10.work`, workflow space `0`, current work this file, pack this file, assignment state `returned`, runtime book `00.00.01.law`, runtime space `0`, runtime band `0300-0399`, runner `00.kernel/00.00.01.law/0302.run/02.run.003.py`, and runner sha256 `bbca135691ba4e873e27b9322b1ad6d79deeb59107eb7d377f7d20014067d50c`. `validate` added `validate: pass`. Transcripts: `evidence/05.06/where.txt` sha256 `f663104e963ca1c20ac34c5ac3a0a647f92ee229afe4cc262530482b5c90e62a`, 404 bytes; `evidence/05.06/validate.txt` sha256 `e9acc014b8f7af24a88bfa396d0a9c167ef796255eb2e51071816b2abca3538c`, 419 bytes.

`write_contents.py --check` is `evidence/05.06/contents-check.txt`, sha256 `87227606cafd8f3bb96c52af67eb9eba09d530d45419b26c1de9a82beb4adf41`, 43 bytes, and exits 2. The writer was not run. The contents pages were not edited. They do not name `05.06.md` or `06.06.md`. The goal page was not edited.

A fresh `autocrlf=true` clone was not repeated. Bytecode was kept out of the books by `-B` and `PYTHONDONTWRITEBYTECODE`. Path checks do not confine same-user Python. Normal `run` stays refused. Nothing is seated or activated. No model profile was called.

Paths under `00.kernel` and `labs` in the evidence commit, other than `evidence/05.06/custody.tsv`, `evidence/05.06/text-custody.tsv`, and the gitbytes transcripts, are in `evidence/05.06/custody.tsv`. The `app/` files are in `evidence/05.06/text-custody.tsv` and stay out of the `-text` attribute check.

Evidence commit: fd5d3fc280516ff1ef0b719ea27695d7bcb29df7. `gitbytes.py commit` passed 48 rows in `evidence/05.06/custody.tsv` and 3 rows in `evidence/05.06/text-custody.tsv` at that revision. The manifest, and the five transcripts left out of it, match that commit's blobs. The commit check printed `pass commit: 48 row(s)` and `pass commit: 3 row(s)`. Those lines are `evidence/05.06/gitbytes-commit.txt`, sha256 `66c1053bc44b27a11daa0fe1a0ff48225023891fa54b1813dd2c884d728e3ba7`, 23 bytes, and `evidence/05.06/gitbytes-text-commit.txt`, sha256 `a3259175b3225e28798716b874c3865f14045f7e37167e34268950bfc173f9c6`, 22 bytes. This file does not embed the hash of the commit that contains this return.

## Review — Codex Prime
PENDING.
