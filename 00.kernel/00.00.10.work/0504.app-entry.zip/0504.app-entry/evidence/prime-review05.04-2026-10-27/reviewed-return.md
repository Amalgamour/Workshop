# 05 — Refuse pre-existing fixture output aliases
version: 001
Authorization: draft — 2026-10-27
who: Codex Prime
state: returned
Face: 05
PPPP: 0504
book: 00.00.10.work
keyword: app-entry

## Assignment
Builder: Grok 4.7 (xAI). Reviewer: Codex Prime.
Release: released by the Director, 2026-10-27.
Claim: Grok 4.7 (xAI), session 01a179d2-387a-7661-8702-6e53f95e96b5, 2026-10-27, HEAD 4ae4b06fa72b2a8fc2d9b02521f998a305194262.
Reviewed base: 4ae4b06fa72b2a8fc2d9b02521f998a305194262, branch workshop.
Repair AR-01 and correct AR-02 from the 05.03 Colab and Prime review. Keep the working designated-container checks. Do not integrate the worker bridge.
The packed page is `evidence/05.04/packed/05.04.md`, sha256 `8158c0971ba758287e982a6e83d9ad3f8a84e8db8218dd179b9410080e87e844`, 3478 bytes.

Director, verbatim:

> Read and execute:
> D:\Git\lib-build\00.kernel\00.00.10.work\0504.app-entry\05.04.md
>
> I release this batch. Repair AR-01 and correct AR-02 as specified. Preserve predecessors,
> record failure-before and refusal-after evidence, and keep the
> existing designated-container behavior working.
>
> Return on that page for Codex Prime review.
> No bridge integration, activation, model calls or main merge.

## Return — Grok

Did. The entry refuses an output name, and the sibling temporary name, when that directory entry is already present. The check is `lstat` inside the existing `check_allowed_root`, before the payload is imported. Hard links and a dangling junction stop, and the planted bytes stay. `app/README.md` now states that the caller hash, the fixture hash, the stamp, the card, and the path are integrity and context. Runners 001, 002, and 003, the card, and the inventory payload are unchanged. The suite exited 0: pass 12, expected-refusal 46, skip 1, fail 0.

Blocked. Bridge integration, activation, model calls, and a main merge stay outside this release. A file symlink could not be created in this process (`WinError 1314`). The path check does not claim resistance to a later change, and it is not an operating-system sandbox. Normal run stays refused.

Need. Codex Prime review of this page. Fixture-only bridge integration stays proposed and is not released.

## #01 — Notes and preserved source
Notes are `06.04.md` on this page, sha256 `4af862d154f79ed5e24ebb71c9d1d5fe98f041001be5c9e208ba8dc4bbf1b33b`, 6029 bytes. `05.03.md`, probe P9 in `evidence/colab05.03/probes.py`, and `evidence/prime-review05.03-2026-10-27/hardlink-proof.json` were read and left unchanged. `06.01.md`, `06.02.md`, and `06.03.md` were not edited. Those reviews do not gain a claim that their checks covered AR-01.

The notes file was written after the failure-before capture and after the first edit of `app/context.py` and `app/README.md`. The reading named above was done before that edit. `06.04.md` records that order.

No runner body changed, so there is no `02.run.004.py`. `02.run.003.py` stays the configured path and hash. `02.run.001.py`, `02.run.002.py`, and `0302.run/02.md` stay byte-exact. Nothing wrote `02.run.py`. The payload stays `dd6a78b5a3781fe840e68950805b9838e569095d15dac3c678f00782341ed69b`, 2988 bytes.

The suite pin for `0502.workflow-start/05.01.md` was `f3e9ee3e05de5a7e11c407c89bf4205ec4b408d5c1c7a8a96175d71cda461000`. Commit `b471a24` appended Prime's additive correction. The committed file is `7f43ea75f0fc6f01229e0171312bc1f42a067df7a27e9689eab602d5f1bcfe17`, 20298 bytes. This batch does not edit that page. The pin now names those committed bytes.

## #02 — Repair and regression
The interpreter was `C:\Users\misg\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe`. Below, `<py>` is that interpreter and `<ws>` is `D:\Git\lib-build`.

`check_allowed_root` in `app/context.py` is the one implementation. The entry calls it before the runner is imported. `02.run.003.py` calls the same function before `run_main`. The signature stays `(fixture_root, fixture)`. Both the output relative path and the sibling temporary (the output file's name plus `.tmp`) go through `resolve_under` and the designated-container check. Presence is `lstat` on the lexical path. `exists()` is not the test, because it is false for a dangling junction. An occupied name stops the run. The name is not removed and not replaced. A resolved path that leaves the root still stops as `path escapes the root`.

On the unrepaired tree, before this repair, an isolated `git archive` of HEAD `4ae4b06fa72b2a8fc2d9b02521f998a305194262` planted the standard fixture under `app/scratch` and hard-linked `output/inventory.json.tmp` to that copy's `app/README.md`. `test-run` exited 0. Link count 2. Isolated README `64a7953d726e764c81208c16eaf294aa2d76ee87cdb2b7101a5e1693547037d9` became `1b465c3517a5b4575a3ff5b2cdbeeb37220d83b262afb5f69864b292093e13c0`. Stdout contained `result: pass`. The real README stayed `64a7953d726e764c81208c16eaf294aa2d76ee87cdb2b7101a5e1693547037d9`. Payload `dd6a78b5a3781fe840e68950805b9838e569095d15dac3c678f00782341ed69b`. Transcripts: `evidence/05.04/failure-before.stdout.txt` sha256 `240d566fa7909e422827e236d7cc6e421e8b9506f902bfad0e2c25b0a455de23`, 825 bytes; `evidence/05.04/failure-before.stderr.txt` empty; `evidence/05.04/failure-before.json` sha256 `1d42862659b5e7c0fc30b2b5e2652a147e2f64882b543cacf167efb625c305a6`, 533 bytes.

On the repaired context, the same shape in a new isolated archive, with only the repaired `app/context.py` overlaid, stopped before the payload. Exit 2. Stderr: `stop: output temporary name is already present`. Stdout empty. No `result: pass`. Link count stayed 2. The link bytes and the isolated README stayed `64a7953d726e764c81208c16eaf294aa2d76ee87cdb2b7101a5e1693547037d9`. No `output/inventory.json` was written. The real README stayed the repaired hash `60cb725a54b37378ee53a8ab89e5aa7d603394c269bee7d6eda578a5b64b8ee0`. Transcripts: `evidence/05.04/refusal-after.stderr.txt` sha256 `ef120639fd9b2da7e2c4b41554eff54bd28c01fd4a5a635f4ac4458f317905b3`, 47 bytes; `evidence/05.04/refusal-after.stdout.txt` empty; `evidence/05.04/refusal-after.json` sha256 `80e098a7bb234c215223e8dfadc7aeceda2cac297b5e780c11eb6529caf798e2`, 714 bytes.

The suite refuses an existing ordinary output (`output name is already present`), an existing ordinary temporary (`output temporary name is already present`), a direct hard link on the output name, a hard link on the temporary name, and a dangling directory junction on the temporary name whose `exists()` was false. Each planted victim stayed byte-for-byte, and the link or junction stayed in place. The dangling file symlink was skipped: `WinError 1314: a required privilege is not held by the client`. A fresh inventory, with both names absent, matched `expected-inventory.json`.

Preserved successes: the scratch fixture from a foreign current directory, the same inventory from an explicitly named external container with the output moved to `output/inventory-relocated.json` so the copied `output/inventory.json` stayed, and a fixture root under this page's `fixtures/` directory with no `--container`. Existing container, relocation, and refusal tests still refuse. Normal run refuses. No bytecode was written under `00.kernel` or `app`.

Suite summary `pass 12 expected-refusal 46 skip 1 fail 0`, exit 0. Log `evidence/05.04/test-log.txt` sha256 `0ec38f4906db06ebe78c9562138caa66e3a972917c4cf63090fb10c65ba9a541`, 27938 bytes. The scratch inventory copied from that run is `evidence/05.04/inventory.json` sha256 `1b465c3517a5b4575a3ff5b2cdbeeb37220d83b262afb5f69864b292093e13c0`, 363 bytes.

`app/README.md` no longer says this slice runs the one reviewed fixture payload. The caller supplies the payload hash and the fixture records that same hash. The entry checks the hash, the stamp, the card, and the path. That is integrity and context. No approval allowlist was added. Nothing in the program pins `dd6a78b5` as the only legal payload.

Commands on the returned workspace:

```text
<py> -B <ws>/app/librarian.py where --root <ws>
<py> -B <ws>/app/librarian.py validate --root <ws>
<py> -B <ws>/app/librarian.py test-run --root <fixture> --candidate 00.kernel/00.00.01.law/0310.inventory/02.inventory.py --sha256 dd6a78b5a3781fe840e68950805b9838e569095d15dac3c678f00782341ed69b [--container <external-container>]
```

`where` printed desk `00.kernel`, work book `00.00.10.work`, workflow space `0`, current work this file, pack this file, assignment state `returned`, runtime book `00.00.01.law`, runtime space `0`, runtime band `0300-0399`, runner `00.kernel/00.00.01.law/0302.run/02.run.003.py`, and runner sha256 `bbca135691ba4e873e27b9322b1ad6d79deeb59107eb7d377f7d20014067d50c`. `validate` printed those lines and `validate: pass`. Neither command imported the runner. Transcripts: `evidence/05.04/where.txt` sha256 `331153ee636f0595e6612c70a320bf22228901cc375de7a183693af5e7080614`, 404 bytes; `evidence/05.04/validate.txt` sha256 `8e9c97a3230ba8e138bf1d8a1771648abe6cf383d884a127162cf19af99ab43a`, 419 bytes.

## #03 — Return and custody
The assignment record was hand-edited from waiting to running, then to returned. Clerk did not make that transition. `00.live.md` was regenerated with `render_live.py`. The renderer was not edited. `render_live.py check` printed `check: 00.kernel/00.live.md matches the record` (`evidence/05.04/render-check.txt`, sha256 `0cb6ad63c6a61988153304a55d3d7619a74207942f44328a35b8b9b12137cc3c`, 47 bytes).

Assignment bytes: waiting record `evidence/05.04/assignment-before.md` sha256 `50ad15e5903c05cc2ac015d48ea1327b7faee8d4b2affa822b0b70517db79a05`, 530 bytes. Running `evidence/05.04/assignment-running.md` sha256 `c530c08e6073c8f49aac03b73da9dc87928b6b23ae17aee0388035dc56b6c5d5`, 498 bytes. Returned record sha256 `98a84cf3cd98008b03f8108043e3ff31e84e5b4832e815493ece1899de6f74a4`, 504 bytes. Views: before `evidence/05.04/live-before.md` sha256 `2354b06b640d2765db375f4679ba3cd926eac97351b0c61b680bb6e4fb1117dc`, 1145 bytes; running `evidence/05.04/live-running.md` sha256 `e467564e1329f6bf74269fc243ac99ad412f875004d5a4adb9b340172baaac9a`, 1113 bytes; current `00.live.md` sha256 `bec62357e3a17b35a0df96f3b62205d42ac59073ba71cfe0a7d7287967f84a65`, 1119 bytes. `waits_on` names Codex Prime's review of this page. Bridge integration is not released. `next` stays the proposed integration.

Changed source hashes: `app/context.py` `5b1a31d47bb9f9b465a8492541467abbd9bd3a99ae524be7aa0dbffe2380eb9f` (22063 bytes). `app/tests/test_entry.py` `18519d8608fdd70dacaac49e153ab56277c558cd2295ab5af1d91e7cdddbb0ae` (43790 bytes). `app/README.md` `60cb725a54b37378ee53a8ab89e5aa7d603394c269bee7d6eda578a5b64b8ee0` (3696 bytes). Unchanged: `app/librarian.py` `3d9aa20a55e66def29325cfe85d0056f69213807ba5c247b90c8116ac3c26a77` (4480 bytes). `app/development-workspace.json` `b6f4e13b3157416a05b102dfe8a01605e007c2608ba6b0fd06987757d2e33018` (538 bytes). Runner `02.run.001.py` `af207d4d4f68ddcc2c22b7b1dced081b29dcbbfa6675d152ff7efa37871dcb8c` (13805 bytes). `02.run.002.py` `4a962d3a6edd26428b75e27ad82113708e510a1e770522d34b9e8bb11ec2b0f4` (9470 bytes). `02.run.003.py` `bbca135691ba4e873e27b9322b1ad6d79deeb59107eb7d377f7d20014067d50c` (10143 bytes). Card `02.md` `95062ea60f8b923c3bda1cf603f394e54e56d961f42af13c9520031bf13bb95f` (746 bytes). Payload `dd6a78b5a3781fe840e68950805b9838e569095d15dac3c678f00782341ed69b` (2988 bytes).

Kernel paths in the evidence commit, other than `evidence/05.04/custody.tsv`, `evidence/05.04/text-custody.tsv`, and the gitbytes transcripts, are in `evidence/05.04/custody.tsv`. The `app/` files are in `evidence/05.04/text-custody.tsv` and stay out of the `-text` attribute check. Root `README.md` and `.gitignore` were not changed. Root `README.md` sha256 `33dccc3fd3fd5f21a4d35ee03a3f17dd6ab0262314e074d25d332178d03fcbb4`, 5417 bytes, still says AR-01's hard-link route blocks integration pending `0504/05.04`.

`write_contents.py --check` is `evidence/05.04/contents-check.txt`, sha256 `87227606cafd8f3bb96c52af67eb9eba09d530d45419b26c1de9a82beb4adf41`, 43 bytes, and exits 2. The writer was not run. `0011.contents/01.003.md` still lists this page's 05.01 set and does not list `05.04.md`, `06.04.md`, or `evidence/05.04/`. The goal page was not edited. Finish line 2 stays partial and still describes the 05.01 return. Jobs, checker, clerk, and face are not integrated.

Failures/skips/remaining risks: the suite recorded one skip, the dangling file symlink, and no unexpected failure. A fresh `autocrlf=true` clone was not repeated. Bytecode was kept out of the books by `-B` and `PYTHONDONTWRITEBYTECODE`. The path checks do not confine same-user Python. A name check made before the payload runs is not a claim of resistance to a later change. Normal run stays refused. Nothing is seated or activated. The adapter and the loader were not activated. `02.run.py` was not created. The worker bridge was not integrated.

`returns/clerk-handoff-proposal-claude-2026-10-27.md` was already untracked and was not staged. Historical reviews, pack inputs, and earlier evidence directories were not edited.

The entry refuses a pre-planted output hard link before the payload runs, and it still performs the declared fixture inventory from a designated container.

Evidence commit: 4b0b26071649d10e0012241da63fd9051cd9a354. `gitbytes.py commit` passed 28 rows in `evidence/05.04/custody.tsv` and 5 rows in `evidence/05.04/text-custody.tsv` at that revision. The manifest, and the five transcripts left out of it, match that commit's blobs. The commit check printed `pass commit: 28 row(s)` and `pass commit: 5 row(s)`. This file does not embed the hash of the commit that contains this return.

## Review — Codex Prime
PENDING.
