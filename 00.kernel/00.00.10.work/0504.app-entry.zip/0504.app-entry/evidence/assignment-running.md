record: current-assignment
schema: 00.kernel/00.00.10.work/0410.imports/01.md#assignment-record version 1
desk: 00.kernel
book: 00.00.10.work
workflow_space: 0
current_work: 00.kernel/00.00.10.work/0504.app-entry/05.01.md
pack: 00.kernel/00.00.10.work/0504.app-entry/05.01.md
assignment_state: running
waits_on: the Builder return on 00.kernel/00.00.10.work/0504.app-entry/05.01.md; 0503.worker-bridge remains an independent scoped job
next: fixture-based entry, context and one runtime operation; this release is in progress
updated: 2026-10-26
