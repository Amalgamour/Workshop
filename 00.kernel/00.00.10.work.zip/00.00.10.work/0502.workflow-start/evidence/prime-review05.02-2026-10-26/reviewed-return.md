# 05 — Read-only published-book orientation checker
version: 001
Authorization: draft — 2026-10-26
who: Codex Prime
state: draft; awaiting Director release
Face: 05
PPPP: 0502
book: 00.00.10.work
keyword: workflow-start

## Assignment
Executor: Claude Colab. Reviewer: Codex Prime.
Release: PENDING. Claim: PENDING.
Build one small read-only checker for the work book's declared contents and entry
pointer at a pinned Git revision. This supplies a missing check, not a new authority
or another contents writer. Grok owns app changes; preserve that independent lane.
Return here. Use new 06.03.md for notes: 06.02.md is RESERVED for the Observer pilot.

## Why and baseline
Prime's 0502/05.01 review found a mismatch between a return's statement and the
contents candidate. At a5853b7ecdd076a77b4b106b057cea568e205bfb, 01.002 lists an
unpublished 0503 page. At 15b9cceb3438b8a91acfd8d3155b9b0d5fce29ae, book 00.md explicitly
selects 01.003; that candidate advertises an unpublished 0505 and omits local 0503.
The old writer's --check compares only 01.001, so it cannot validate the selected
candidate. Hash custody alone does not prove the contents describes the Git tree.
Published and local views differ deliberately while workers have uncommitted files.
This slice checks the PUBLISHED TREE only and labels that scope honestly.
Inputs: evidence/pack05.02/source-manifest.tsv and exact inputs/ snapshots.

## #01 — Notes and exact inspection contract
Write notes first, then implement under labs/book-orientation-pass01/ using only
the standard library and installed Git. Proposed CLI (adjust labels if justified):
python -B check_book.py --root <repository> --revision <commit> --book 00.kernel/00.00.10.work
Resolve the supplied revision ONCE to a commit SHA. Use git show/ls-tree object
reads at that SHA, never the changing working directory, index or highest version.
Read the book's explicit 00.md contents pointer, supporting its current provisional
sentence as an explicitly documented local format. Also permit an exact --contents
path to inspect a declared candidate without claiming the sentinel selected it.
Do not invent generic kernel pointer grammar. Missing/ambiguous/unsupported pointers
must be a clear refusal, never a silent fallback to 01.001 or the newest candidate.

## #02 — Checks and output
Compare the chosen contents Pages table with the pinned book tree: missing/extra
page rows, duplicate rows/page numbers, missing/extra direct files and subdirectories,
and incorrect recursive tracked-file counts for directory summary entries. Validate
the Book files list and the explicitly listed Other books sentinel paths. Resolve
relative paths lexically inside the repository; reject escaping/absolute paths.
Do not attempt to infer every prose reference or validate arbitrary Markdown.
Unsupported row/list formats must produce a refusal or explicit incomplete result,
never a clean pass. Document exactly which links and fields are covered.
Produce machine-readable findings plus a concise human summary with commit SHA,
book, selected contents path/hash and selection source. Suggested exits: 0 clean,
1 findings, 2 invalid input/unsupported structure/tool failure. All findings advisory.
No edits, repair, promotion, closure or queue updates by the checker.

## #03 — Verification and demonstration
Use disposable synthetic Git repositories for meaningful tests: a correct book;
missing published page despite an untracked local folder; files/count mismatch;
duplicate page identity; explicit pointer to an older candidate with a newer one
present; missing/ambiguous pointer; path escape; and unsupported table syntax.
Also prove working-tree changes do not alter results at a pinned commit. Assert
read-only behavior on the inspected checkout; no shared Git mutation.
Demonstrate against a5853b7 and 15b9cceb3438b8a91acfd8d3155b9b0d5fce29ae. For the old
revision, separately inspect 01.002 via --contents if the sentinel points elsewhere;
do not pretend the candidate was selected. Record failures as expected findings,
not failed implementation tests. Do not repair source contents or run the writer.
No network, dependencies, app execution, external models or shared test stores.

## #04 — Reread and return
Reread the tool/docs against the contract, disposition notes and record exact
commands, tests, hashes, findings and limitations in evidence for this batch.
Return starting Did, Blocked, Need, then explain what works, what the tool still
does not establish, and one recommended bounded next action. No broad link crawler
or process redesign. Findings must not silently become new global kernel law.

## Scope
May edit this 05.02.md, create 06.03.md and evidence/check05.02/ on this page, and
create labs/book-orientation-pass01/ only. Preserve all earlier work and packed
inputs. No edits to 06.02 (Observer), other book pages, app/, worker bridge lab,
old writer, assignment/view/queue, imports, kernel law/syntax, or other workers.
No Git writes in the shared repository: no add/commit/push/fetch/checkout/reset/stash.
Tests may initialize and commit their own disposable fixture repositories only.
No seating, activation, Director decisions or automatic dispatch.

## Return — Claude
Release: the Director, chat 2026-10-26: "Read and execute: D:\Git\lib-build\00.kernel\00.00.10.work\0502.workflow-start\05.02.md I release this batch. Build and test the read-only published-book orientation checker. Use the pinned Git revisions and distinguish published files from uncommitted local work. Preserve Grok's app work, the worker bridge, and the Observer's reserved 06.02.md. No shared Git writes or source-content repairs. Return on that page for Codex Prime review."
Claim: claude-opus-5-5 (Anthropic), Colab, claimed 2026-10-26T17:43-05:00.
Execution: RETURNED for Codex Prime review, 2026-10-26. No shared Git write, no source-content repair, no writer run. Grok's app work, the worker bridge and the reserved 06.02.md were not touched.

Did:
- Verified pack05.02: all 5 snapshots match both their pins and the blobs at 15b9cceb.
- Wrote the notes first: 06.03.md (sha256 c1312b41…), with inputs I01-I02, contract C01-C05 and dispositions N01-N05.
- Built labs/book-orientation-pass01/check_book.py, read-only, standard library and Git only. The lab manifest is labs/book-orientation-pass01/evidence/SHA256SUMS.txt (sha256 06168454f0e3948ff673e93abccb57661f9d6379e96fc61bcddb9d92b6887a1a): check_book.py 20db09a1…, tests 677f60ac…, README 15eed493…
- Tested it with 14 synthetic-repository tests, passing 14/14 in dev mode and in default mode, with 0 skipped and 0 warnings. The first run had 1 error, in my test, not the tool: argparse refuses `--revision --output=x` itself, with no JSON. The test now passes the value as `--revision=--output=x`, reaching the checker's own refusal. That run is kept as evidence/check05.02/tests-run01-test-error.txt.
- Demonstrated against the two pinned commits. Evidence is in evidence/check05.02/ (manifest SHA256SUMS.txt, sha256 3d1739da2074b2897bbf02e881a86af826d3e7ea5de6c52e38ec9ce886913d8d).
Blocked: nothing.
Need: nothing from the Director for this batch.

Commands, from the lab folder:
`python -B check_book.py --root D:\Git\lib-build --revision <commit> --book 00.kernel/00.00.10.work [--contents 0011.contents/<file>.md] [--json]`
`python -B -X dev tests/test_check_book.py -v`

Demonstration results. Expected findings, advisory, not repaired:
- a5853b7 resolves to a5853b7ecdd076a77b4b106b057cea568e205bfb. The sentinel selects 0011.contents/01.001.md (30ae5faf…). Findings: extra-file 0011.contents/01.002.md (in the tree, not listed); extra-page 0502.workflow-start (published, no row). Exit 1.
- a5853b7 with --contents 0011.contents/01.002.md (a4e31538…), reported as "on the command line (not selected by the sentinel)". Findings: extra-file 0011.contents/01.002.md (the candidate does not list itself); missing-page 0503.worker-bridge (listed, not published). Exit 1.
- 15b9cceb3438b8a91acfd8d3155b9b0d5fce29ae. The sentinel selects 0011.contents/01.003.md (e6d97a94…). Finding: missing-page 0505.observer-design (listed, not in the published tree). Exit 1.
Shared checkout: HEAD 15b9cceb, the .git/index bytes and the refs were identical before and after. The status listing differed only by this batch's own evidence files, written into evidence/check05.02 during the run. A rerun with its outputs outside the repository left the status (excluding that folder) and the index bytes identical (NOTE-status-fingerprint.txt).

What works:
- Selection is exact: the sentinel's one pointer, or a labelled explicit candidate. There is no fallback and no highest-version choice.
- Reads come only from the resolved commit, so local untracked pages (0503 today) can never look published. A test proves working-tree and index edits do not change a pinned result, and that the inspected checkout's status, HEAD and index bytes are unchanged.
- The tree comparison covers missing and extra pages, files and subdirectories, recursive counts, duplicate rows, duplicate page numbers (rows and tree), the Book files list, and the Other books paths with lexical escape refusal.
- Unsupported table or list shapes, and missing, ambiguous or dangling pointers, refuse with exit 2, never pass.
What the tool still does not establish:
- that the published tree is the right content to publish;
- that the pointer form is general kernel grammar (it is this book's local provisional format);
- anything about prose links, face contents or local work;
- correctness for nested page layouts or gitlinks (a gitlink inside a page would be counted as a file);
- authority: a clean result is advisory only.
Recommended next action (bounded): when the next contents candidate is written, run this checker at that candidate's commit, with its findings recorded on the batch, before the book's 00.md pointer is moved to it. Do not wire it into a writer or a gate until Prime accepts it.

## Review — Codex Prime
PENDING.
