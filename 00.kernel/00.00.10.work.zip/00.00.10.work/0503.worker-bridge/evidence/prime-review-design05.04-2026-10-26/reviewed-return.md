# 05 — App-to-worker bridge integration design
version: 001
Authorization: draft — 2026-10-26
who: Codex Prime
state: draft; awaiting Director release
Face: 05
PPPP: 0503
book: 00.00.10.work
keyword: worker-bridge

## Assignment
Executor: Claude Colab. Reviewer: Codex Prime.
Release: PENDING. Claim: PENDING.
Design the smallest useful connection between the development app and the accepted
protocol-worker bridge. Design only; no implementation, process launches or model calls.
Return a proposal from which Prime can write a bounded implementation batch.
Inputs: evidence/pack05.04/source-manifest.tsv and its exact inputs/ snapshots.

## Current state and independence
Prime accepted 05.03 for its protocol-worker lab contract, not app activation.
0504 app entry needs APP-01 repaired: a fixture can masquerade as app source and
overwrite app/README.md. Grok owns that repair in 0504/05.02. Read its snapshot,
do not fix it, and do not assume the future interface is implemented or accepted.
Use the pinned snapshots for this design. Current app files can change concurrently;
report relevant differences instead of editing or depending on a moving target.

## #01 — Notes, reuse and module boundary
Write new 06.04.md notes first. Trace the existing app entry, context validation,
adapter, request/result verifier and persisted receipts. Identify what can be
reused unchanged, what integration glue is needed, and exact responsibilities.
Propose where the integration belongs, respecting existing N3NN runtime rules and
candidate/active separation. Do not allocate a page or create another loader.
Avoid copying the lab into production without a dependency/installation decision.

## #02 — One end-to-end fixture job
Propose one explicit development-only invocation, request shape and response shape.
The reviewed fixture worker receives one synthetic input, produces one small
hash-verified artifact and a durable receipt. Show a concrete example with exact
fields and file locations, rather than just naming modules. The job is a protocol
test worker, not a claimed AI exchange. No automatic dispatch, loop or scheduling.

Trace who records the job, resolves context, verifies the release, selects the
allowlisted backend, starts the process, verifies artifacts and exposes the receipt.
Do not treat a request's release text, a fixture label, successful transport, or
receipt collection as approval. State which authority checks already exist and
which are still proposals. Keep test inputs, outputs, stores and logs inside
designated fixture containers. The exact container interface depends on APP-01.

## #03 — Failure and recovery contract
Give expected observable outcomes for success, malformed result, wrong hash,
timeout, incomplete output/retained pipes, repeat identical delivery, conflicting
delivery identity, interrupted receipt persistence and invalid fixture scope.
Preserve uncertainty and no automatic relaunch after a launch with unknown outcome.
Keep transport, artifact validity, review and acceptance separate. Do not promise
process-tree termination, authentication, a sandbox or general concurrency.

## #04 — Implementation slice and acceptance
Propose ONE next implementation batch with files/modules to change, dependencies,
an exact runnable demonstration and meaningful acceptance checks. Include a fresh
process reading the persisted receipt and replay without a second worker launch.
APP-01 repair and its Prime acceptance are a prerequisite to shared app execution;
design work may proceed now. Avoid adding universal grammar, a dispatcher, SQLite,
UI, bots or real-model integration to this slice.

## #05 — Reread and return
Reread the whole proposal against the snapshots and Prime's 05.03 review. Account
for notes as integrated, rejected with reason or deferred visibly. Return on this
page starting Did, Blocked, Need; then the proposed interface/module plan, example,
failure table, bounded next slice and any actual Director decisions with effects.
Also answer: what works well, what tool update is needed, what a cold reader lacks.
Do not ask the Director to choose routine implementation details you can recommend.

## Scope
May edit only this 05.04.md and create 06.04.md plus evidence/design05.04/ under
this page. Preserve earlier batches and packed snapshots. No code changes, source
edits, lab execution, shared assignment/view/queue changes, Git writes, dependencies,
network requests, paid calls, role changes, approvals, seating or activation.
This page is a proposal until the Director releases it for the design work.

## Return — Claude
Release: the Director, chat 2026-10-26: "Read and execute: D:\Git\lib-build\00.kernel\00.00.10.work\0503.worker-bridge\05.04.md I release this batch for design work only. Use the pinned input snapshots. Design the smallest app-to-worker integration, including a concrete fixture exchange, failure handling, and the next bounded implementation slice. Return on that page for Codex Prime review. Do not change code, run workers, make model calls, write to Git, or alter Grok's work or the shared assignment."
Claim: claude-opus-5-5 (Anthropic), Colab, claimed 2026-10-26T17:30-05:00. Design only.
Execution: RETURNED for Codex Prime review, 2026-10-26. Design only: no code changed, no worker or lab run, no model call, no Git write, no shared-record edit, Grok's work untouched.

Did:
- Verified all 13 pinned snapshots; live equal to snapshot at the start and the end.
- Wrote the notes first (06.04.md, sha256 69a662ad…: trace T01-T05, notes N01-N10 with dispositions).
- Wrote the design: evidence/design05.04/DESIGN.md, plus example/job.json, example/input.txt, example/expected-result.json, example/worker-bridge.json, and reference-receipt.json, copied from the accepted lab demo (81e3db7a…). Manifest evidence/design05.04/SHA256SUMS.txt, sha256 1ecaf808df3587415e4bb155da0749b597de06b12319f259b028c940c12c09fa.
Blocked: nothing for the design. The implementation is blocked on APP-01 (0504/05.02): the designated container interface does not exist or is not accepted yet.
Need: APP-01 repaired and accepted by Prime before the slice in #04 is packed. The slice's pin list must add canon.py, ids.py and fixtures/worker_fixture.py, which pack05.04 did not pin; their live hashes equal the accepted pass 03 manifest.

Module plan (#01): reuse the lab bridge unchanged, loaded by exact per-file SHA-256. app/worker-bridge.json pins 8 files: __init__, canon, ids, envelope, verify, adapter, profiles.json, worker_fixture. This is the same pattern as the existing runner pin, so it is not a new loader. Glue is one new app module, app/worker_bridge.py: build the envelope from a job plus the container, enforce allowed_kinds = [protocol test worker], check work_ref == the record's current_work, then call deliver, status or recover. librarian.py gets three thin development subcommands: bridge-test, bridge-status, bridge-recover. context.py is not changed by this slice (APP-01 owns its change). No page is allocated, no N3NN band is used, nothing is copied into law or the app package.

Example (#02), DESIGN.md section 4:
- The container holds a synthetic released record, current_work 0501.fixture/05.01.md, bridge/job.json, bridge/input/input.txt (22 bytes, f1f6c82d…), bridge/output/ and bridge/store/.
- `python <ws>/app/librarian.py bridge-test --root <container> --job bridge/job.json`: the fixture-ok worker writes result.json = {"count":3} (0c07187e…), and the adapter writes store/bridge-0001/receipt.json.
- The command prints transport delivered, collection collected, claimed done, then "review: not performed" and "acceptance: not performed", and exits 0.
- A fresh process, bridge-status, prints the same receipt hash.
Authority: existing checks are the live-root refusal, the record released (in fixture mode a synthetic record: it proves the path, not authority), never 00.live, and the lab's envelope, ids, limits, allowlist and artifact checks. Proposed checks are the APP-01 designated container, work_ref == current_work, the allowed kind, and the bridge file pins. The release text, a fixture label, transport success and collection are never approval.

Failure table (#03), DESIGN.md section 5. Exit codes: 0 collected, 2 refused before launch, 3 delivered but not collected (or a claimed failure), 4 uncertain.
- 4: malformed result (and partial, bad-shape, dup-keys); timeout; incomplete-output with the retained readers named and a bounded return.
- 3: wrong artifact hash; a missing or escaping artifact.
- Repeat identical: replayed, 1 launch.
- 2: conflicting identity; invalid fixture scope (live root, an undesignated container, a source tree, a path escape, a bad id, an unknown profile or kind, work_ref ≠ current_work, not released, bad limits, a pin mismatch).
- Interrupted receipt: status uncertain, then bridge-recover rebuilds the receipt from the recorded attempt with no launch. A launch with no attempt stays uncertain, and only a new delivery_id moves on.
No automatic relaunch, ever. Transport, collection, review and acceptance are kept apart. No promise of process-tree kill, authentication, sandbox or concurrency.

Next slice (#04), DESIGN.md section 6: "app-to-worker fixture exchange, protocol workers only".
- Files: new app/worker_bridge.py, app/worker-bridge.json and app/tests/test_worker_bridge.py; changed app/librarian.py and app/README.md. Standard library only.
- Demonstration: bridge-test exits 0; a fresh process's bridge-status gives the same receipt hash; bridge-test again replays with launches.log at 1 line.
- Acceptance: every failure row reproduced with its exit code and bounds, under an outer watchdog; refusals before any launch or outside write; protected bytes unchanged (app/README.md, context.py, the pinned lab, the live work book, the record); a tampered pin refused at import; no bytecode; the app suite and the lab's 30 tests still pass; no dispatcher, loop, SQLite, UI or model.

Director decisions:
- D-1 (deferred, not needed now): the long-term home of the bridge code (a law 03NN candidate, or an app package). It affects custody and lookup. Recommended: keep it pinned in the lab until one real exchange is accepted.
- D-2 (already pending): the named real-model release.
Everything else is routine, and recommended in DESIGN.md.

Reread (#05): the proposal was checked against the 13 snapshots and Prime's 05.03 review. It keeps the lab contract's limits (retained readers, direct child only, not a sandbox) and adds no new runtime claim. All notes are accounted for in 06.04: integrated N01-N06 and N09; N07 deferred; N08 rejected with a stated limit; N10 kept.
Works well: the receipt keeps transport, outcome, collection and review apart; replay without relaunch; the hash-pinned import pattern already exists.
Tool update needed: a packing check that a pinned module's imports are pinned too; and a page edit helper that keeps each page's own line endings (05.04 is LF, while the earlier faces of this page are CRLF; my first claim edit used printf and turned "\00" in a path into two NUL bytes, which I repaired; the instruction text above the Return is byte-identical to the packed page, sha256 114d5df6…).
A cold reader lacks one place listing the authority checks that exist versus those proposed (now DESIGN.md section 3), and the APP-01 container interface, which is unwritten.

## Review — Codex Prime
PENDING.
