# 05 — Worker bridge bounded cleanup
version: 001
Authorization: draft — 2026-10-26
who: Codex Prime
state: returned for Codex Prime review, 2026-10-26 (claude-opus-5-5). Packed snapshot: labs/worker-bridge-pass01/evidence/pass03/05.03.packed-snapshot.md
Face: 05
PPPP: 0503
book: 00.00.10.work
keyword: worker-bridge

## Assignment
Fix the one remaining reproducible cleanup-deadline gap BR-01b. Preserve the
verified pass02 corrections and contract. Executor: Claude Colab; reviewer: Codex.
Release: PENDING. Claim: PENDING.
Inputs: 05.02 Review and evidence/prime-review-pass02-2026-10-26/. The pass02 source
manifest pins reviewed code: lab evidence/pass02/SHA256SUMS.pass02.txt.

## Scope
Only this 0503 page and labs/worker-bridge-pass01. Preserve earlier batches,
reviews, test outputs and manifests; capture the current adapter source before
editing and write separately named pass03 evidence. Notes: 06.03.md. No Git writes,
app/shared-record changes, kernel changes, model calls, account/spend changes,
tools for Observer, or process-tree manager. Grok owns its independent work/lane.
Keep current execution state distinct from the immutable packed snapshot; header
and Return should agree when the work is returned.

## #01 — Add the inherited-pipe regression before changing implementation
Use Prime's worker/driver and blocked stack to reproduce. Direct child reads the
request, starts a SELF-TERMINATING descendant inheriting stdout/stderr, and exits.
The adapter is blocked in s.close() after bounded reader-thread joins. Current
elapsed about 5.078 s, timeout 0.2 s plus cleanup allowance 2.0 s.

Put this in a fresh scratch fixture with an outer watchdog. Record failed result
before fixing. The test must check elapsed return time, cleanup.complete=false,
uncertain/incomplete-result behavior and no automatic relaunch. Use a generous
documented startup margin that still fails the reviewed five-second blockage.
All descendants must self-terminate so failed tests leave no persistent worker.
result: DONE, before any implementation change. New tests/test_pass03.py with tests/_driver_pass03.py. Each delivery runs in an outer watchdog subprocess (40 s). New protocol test workers:
- `fixture-inherit-pipes`: reads the request, starts a descendant that inherits stdout and stderr (stdin DEVNULL) and exits by itself after 5 s, then exits.
- `fixture-inherit-pipes-after-result`: writes a complete valid result first, then starts the same descendant.
The bound is 0.2 s timeout + 2.0 s cleanup + 1.5 s documented start-up margin = 3.7 s. It still fails the reviewed 5.078 s blockage.
Checks: elapsed return time, cleanup.complete false, the outcome uncertain, no collected result, the retained threads named, a retry replayed with no relaunch, and the retained threads finishing on their own.
Failed result recorded first: evidence/pass03/tests/pass03-BEFORE-fix.txt. Both tests failed: "deliver() held for 5.142 s; bound 3.7 s" and 5.160 s. The Prime's own worker and driver (inherited-pipes-worker.py a80d6ff5…, inherited-pipes-driver.py 2c766e96…) run against the pre-fix snapshot in lab scratch: 5.087 s, transport malformed, cleanup.complete false (evidence/pass03/probes/prime-inherited-before.json).

## #02 — Make cleanup return bounded without a blocking close
Remove the synchronous close/wait path that can wait on a reader's buffered-stream
lock after the cleanup budget. Establish clear stream/thread ownership and bounded
cleanup behavior. Do not force-close a stream in a way that simply moves the same
blocking wait elsewhere. Preserve bounded capture, finite timeout, uncertain
outcome, direct-child-only termination and idempotent retry behavior.

It is acceptable to report incomplete cleanup and retained background resources
honestly; document lifecycle/reaping limits. It is NOT acceptable to claim a
bounded adapter return while waiting for an unbounded descendant to close a pipe.
This does not require killing descendants or building an OS sandbox. Partial/late
output must not be promoted to a verified completed result after the deadline.
Snapshot final receipt evidence consistently and state what was not collected.
result: DONE. bridge/adapter.py `_execute` (CONTRACT.md R13-R15):
- Stream ownership: pipes are unbuffered (bufsize=0), and each stream has exactly one owner thread (`_reader` for stdout and stderr; `_write_stdin`, which now loops over partial writes) that is the only code to read, write or close it.
- The synchronous close after the joins is removed. After the deadline plus the 2.0 s allowance, `deliver()` freezes the captures (`_Capture.snapshot()`) and returns. It never closes, joins or waits on a stream a thread still owns, and nothing is force-closed from another thread.
- A thread still running is named in `cleanup.retained`, with a note. It keeps draining its pipe and dropping late bytes (counted, never added to the result), and closes its own handle when the descendant closes the other end, or when the interpreter exits (daemon thread).
- New transport kind `incomplete-output`: the child exited, but its output was not at EOF within the budget. The outcome is uncertain, collection is not attempted, and the partial snapshot is kept as diagnostics and never parsed, even when a complete result was written before the descendant started.
- "delivered" now requires both streams at EOF within the deadline.
- Preserved: bounded captures, the finite timeout, the uncertain outcome on timeout and output-limit, direct-child-only termination, and idempotent replay. No descendant is killed, and no process-tree manager or sandbox was added.
After: the new regression returns in 2.222 s and 2.220 s (retained: stdout reader, stderr reader; those threads finished at 5.135 s and 5.184 s, when the descendant exited; the retry was replayed in 0.008 s with 1 launch). The Prime's worker and driver against the corrected lab: 2.219 s, transport incomplete-output, cleanup.complete false, retained stdout and stderr readers (evidence/pass03/probes/prime-inherited-after.json).

## #03 — Verify, read back and return
Rerun the 28 existing tests plus the new regression. Check small successful work
still closes handles cleanly, stdin timeout stays bounded, both output caps still
work, recovery/replay still work and no malformed-limit/path regression returns.
If resources outlive the adapter call, use a self-terminating fixture and record
their eventual cleanup or explicitly supported lifetime. Preserve failures/skips.

Read changed docs/code back; align the deadline claim with observed behavior and
document remaining process-tree limits. Keep before/after source hashes, commands,
timings and separately named pass03 manifest. Return HERE with actual results,
remaining limitations and recommended next step. Do not call live models or edit
05.02's original return to make it appear this defect had already been solved.
result: DONE. Final runs in fresh lab scratch (evidence/pass03/tests/final-*):
- dev mode: test_bridge 18/18, test_pass02 10/10, test_pass03 2/2;
- default mode: the same 18/18, 10/10, 2/2.
That is 30 of 30 in each mode, 0 skipped (both junction tests ran), 0 warnings. Kept failures and corrections: pass03-BEFORE-fix.txt (2 failures, as intended), and pass03-after-fix-run01-timing-overwritten.txt (passed, but my driver records were per delivery, so the replay overwrote the first call's timing; fixed to one record per call, then run02).
Behaviour re-checked:
- Small successful work closes cleanly: demo-run-02-pass03 delivered and collected, cleanup {complete: true, retained: []}; test_pass02 small success asserts the same.
- The stdin timeout stays bounded: BR-01 probe 0.223 s at 0.2 s; test_pass02 deadline test passes.
- Both output caps: output-limit.
- Recovery and replay: test_bridge recover and replay tests pass.
- No path or limit regression: BR-02 both refused, sentinel unchanged; BR-03 all three refused (evidence/pass03/probes/original-three-probes-after.json).
- No fixture process left after the runs (evidence/pass03/leftover-processes.txt).
Read-back:
- CONTRACT.md: the deadline bullet now states ownership and the observed return bound (about timeout_s + 2.0 s plus start-up; 2.219 s observed), and says it is not a bound on the descendant's lifetime. It adds the `incomplete-output` kind, and R13-R15. Pass 02's overbroad wording is noted.
- README.md: test list, commands, the deadline and process-cleanup limits.
Hashes:
- source before: evidence/pass03/source-before.sha256 (2112cf90011e3e068a30335ab0cb77fdb6e2f4adde717e879601acd82ab7018d), matching the reviewed pass 02 manifest;
- source after: source-after.sha256 (83970b2f5ef9adfda86fd698553720d6b23924c19943c850f38eca0d7697e0dc);
- patch: pass03.patch (c4aa7469a16ac10700bbb12b89ac308f5a356eb9b03dc95c4925571462059e47);
- changed: adapter.py aba589bb -> 27d683b4, worker_fixture.py 4bb8ad2e -> 0d519c8b, profiles.json 898f7690 -> 407804f5 (16 profiles, all protocol test workers), CONTRACT.md dedac263 -> 2d62b602, README.md 2a872ef9 -> 6d9ccf06;
- new: tests/test_pass03.py a89927ee, tests/_driver_pass03.py d8554aa8, tools/page_return_0503.py 92d5c3bf;
- tools/page_edit.py (existing) widened to 05.03 and 06.03, now 0913cc28.
Manifest: evidence/pass03/SHA256SUMS.pass03.txt (160 files, 1ba0dc64ad79db4b5483112793738bc430a7b2c3c72d93015742b8833eec4c5b; verified). The pass 01 (f56ffbbb…) and pass 02 (df06fb1f…) manifests and their test runs are kept unchanged.
Remaining limits:
- not a sandbox; a same-user subprocess;
- only the direct child is killed;
- a descendant can outlive the call, holding a retained thread and pipe handle in the calling process until it closes the pipe or the interpreter exits (reported in cleanup.retained, not reaped);
- the bound is the adapter's return, not real time, and start-up is outside the deadline;
- incomplete-output is conservative: a real CLI that leaves a helper holding stdout is reported incomplete, not collected;
- no authentication; no concurrency control beyond launch.json.
Recommended next step: Prime review of this pass. Then, as a separate Director release, the single named real-model exchange in INVENTORY.md, under its own confinement decision.

## Return — Claude
Release: the Director, chat 2026-10-26: "Read the Prime review on 0503.worker-bridge/05.02.md. I release 0503.worker-bridge/05.03.md. Fix the remaining cleanup deadline issue, preserve the verified corrections, and return on that batch. No Git writes or changes to Grok's independent work."
Claim: claude-opus-5-5 (Anthropic), Colab, claimed 2026-10-26T16:09-05:00.
Execution: RETURNED for Codex Prime review, 2026-10-26. No Git write, no shared-record or app edit, no kernel change, no model call. Grok's work was not touched. The 05.02 return was not edited.
Original BR-01b before/after: before, the regression held 5.142 s and 5.160 s and the Prime's probe 5.087 s (malformed, close() blocked on the reader lock); after, 2.222 s and 2.220 s, and the Prime's probe 2.219 s (incomplete-output, retained readers named, finished at about 5.1 s when the descendant exited). Bound 3.7 s.
Implementation and lifecycle limits: one owner thread per unbuffered stream; frozen snapshot at the return; no close, join or wait after the allowance; `incomplete-output`, never parsed; retained threads and handles live until the descendant closes the pipe or the interpreter exits. Direct child only; no sandbox. See #02, #03, CONTRACT.md R13-R15 and notes 06.03.md (Q01-Q06).
Tests/evidence/hashes: 30/30 in dev and default mode, 0 skipped, 0 warnings; the failing pre-fix run is kept. Manifest labs/worker-bridge-pass01/evidence/pass03/SHA256SUMS.pass03.txt (160 files, 1ba0dc64ad79db4b5483112793738bc430a7b2c3c72d93015742b8833eec4c5b). The packed batch snapshot is evidence/pass03/05.03.packed-snapshot.md (5f8c32a45335108916a0c9b84b0674d0abec1f38f882576fbb9fa91f264f2774). Page faces: 06.03.md is new; 01.md, 06.01.md, 06.02.md, 05.01.md and 05.02.md are unchanged by this pass. This 05.03.md holds the return, so it is not hashed here. Excluded from staging: scratch/ and __pycache__/.

## Review — Codex Prime
Reviewed revision/hash: PENDING
Disposition and integration decision: PENDING
