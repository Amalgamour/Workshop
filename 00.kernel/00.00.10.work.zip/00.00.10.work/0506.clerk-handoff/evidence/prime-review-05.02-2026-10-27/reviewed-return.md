# 05 — Clerk integrity and portable verification correction
version: 001
Authorization: draft — 2026-10-27
who: Codex Prime
state: released by the Director 2026-10-27; claimed by the Second Grok Builder
Face: 05
PPPP: 0506
book: 00.00.10.work
keyword: clerk-handoff

## Assignment
Executor: Second Grok Builder. Acceptance: Codex Prime.
Release: Director, this session, 2026-10-27. Claim: Second Grok Builder, this page only.
Inputs: evidence/pack05.02/source-manifest.tsv and exact inputs/ snapshots.

Technical lead/reviewer remains Claude. Read 05.01 Prime Review and 06.02 in full.
The following contract clarifies/corrects the original lab; it grants no production
authority and no global kernel law. New notes: 06.05.md (leave 06.01-06.03 intact).

## #01 — Preserve before repair
Snapshot the original 9 manifest files and manifest under evidence/repair05.02/before/.
Preserve first-pass sources, raw failures and test/demo records byte-for-byte.
Reproduce CR-01/02/03/04 in disposable external stores, never the shared checkout.

## #02 — CR-01, detect isolated terminal record loss
Add one narrow exclusive-create completion witness for a returned job, independently
recording the expected returned-event digest. Version the changed local store
format explicitly; earlier-format stores must be recognized/refused honestly,
not silently migrated or mistaken for newly valid stores. No new CLI command.
Publish witness before the terminal event, or use an equally explicit reviewed
two-part completion protocol. Readers require both parts and their agreement.
Witness without event, event without witness, a partial witness, mismatch or
extra/planted completion metadata must be incomplete/corrupt, never returned-clean
or a clean claimed state permitting a different return. Repeated identical return
is still idempotent and writes no new witness/event. Partial completion never
auto-resets/retries/deletes records. Keep the entire-store/consistent-prefix rewrite
limitation explicit: this detects isolated damage, not authenticated history.

## #03 — CR-02/03/04/05
At public command boundaries convert expected filesystem OSError into a clear
refused/incomplete diagnostic with exit 2. Do not turn a failed mutation into exit
1 findings or success. Preserve partial records and explain whether a claim event
exists; no silent token replacement. Do not blanket-catch programmer errors as
success. Test the outbox-creation failure after a claim event explicitly.
Make the Git-store refusal test use its OWN disposable git-init repository. No
test may target LAB/_not_created_store or the shared checkout. Run after relocation.
Require nonblank return evidence and a nonempty expected_outputs list for this
slice. Names/claim tokens remain correlation labels, not authentication.
Write NEW manifests with LF, preserving original CRLF manifests unchanged.

## #04 — Verify and return
Run the existing suite and seven-step demonstration in external relocated copies,
plus focused witness-loss/partial-publication, OS-error, blank-field and portable
test regressions. A missing final event with a retained witness must be visible
in reviewer inbox and verify; a different re-return must refuse with no new event.
Show refusal leaves existing evidence untouched. Record skips honestly. Reread
contract/code/docs, disposition notes, and return here with Did, Blocked, Need,
exact source/output hashes and remaining limits. New manifest: lab
evidence/SHA256SUMS.pass02.txt. Do not overwrite the first manifest.
Claude's subsequent independent review goes on NEW 06.04.md; the Director invokes
it manually. Claude may preserve previously scratch-only review artifacts under
evidence/colab-review05.02/ and must disclose if unavailable. Builder never writes
that independent review. Previous findings and replies stay on their source pages.

## Scope
Only labs/clerk-handoff-pass02/, this 05.02, NEW 06.05, and evidence/repair05.02/ on
this page. No other pages, app/bridge/SoF, kernel, old pass01 or shared assignment/
view/queue edits. NO shared Git writes; Prime publishes after review. No model calls,
dispatcher, automatic recipients, approvals, acceptance/closure, OS sandbox or new
services. Tests may git-init/commit only their own disposable fixture repositories.

## Return — Second Grok Builder

Did. Applied the bounded correction on `labs/clerk-handoff-pass02/`. Schema is now `clerk-handoff-pass02/2`. A returned job has an exclusive-create witness, `0003.witness.json`, written before `0003.returned.json` and holding that event file's digest. Readers require both parts to agree. An earlier `clerk-handoff-pass02/1` store is named and refused, not migrated. Filesystem `OSError` at the six commands exits 2 and, when a claim event is already on disk, says so without minting a new token. Blank evidence and an empty `expected_outputs` list are refused. The git-store test uses its own disposable `git init` repository. Notes are on 06.05.md. 06.04.md is not written.

Blocked. Nothing in this slice.

Need. Nothing that has to be decided before review. 06.05 records the witness as a side file rather than a fourth chain event, and records that a lost trailing newline on the returned event is now a mismatch.

Files and hashes. New lab pin: `labs/clerk-handoff-pass02/evidence/SHA256SUMS.pass02.txt`, SHA-256 `08cd3001d887af06df56c65e0f857a77ce38374e3eafc8755942fb5ee69c9760`, LF, 13 files, not including itself. The first pin `evidence/SHA256SUMS.txt` is unchanged, SHA-256 `0d8022900bc20d77e2b1d978a360f80685f79c389f61d4a46702b410d0ad3d52`.

Changed sources:

- `clerk.py` `f469e232f878d042a7a50e6c1ca948d26fdb680de12a6a4220fd8f4513f103ad`
- `README.md` `13e5148f91957a109a2560622c09c87de5369c6e1e3591cb223de252440914cc`
- `tests/test_clerk.py` `2824ca6d5b168065cc9cdcacc6ba009f8e5e3405cef82225ccddc6838f4b7a3d`

`demo.py` is unchanged, `ae6653a928d450bd943e04b454c2789e6a794558373e66b9b819768950b6b50c`. Before-repair copies and the CR-01 through CR-04 reproduction are under `evidence/repair05.02/`. That pin is `evidence/repair05.02/SHA256SUMS.txt`, SHA-256 `7a9beecef0d2707f0f2a5e64cccbe9ca93037a5b1eda2c7605e191509d85419d`.

Demo store, outside the Git working tree: `%TEMP%\clerk-demo-pass02-cn_pw1fv`. Event chain after return, before the tamper:

- `0001.queued.json` `b8bfe741bb6f59752a261fd7935eb642e9863e4e9a580a56e4581c15c8bd4359` prev null
- `0002.claimed.json` `43fd076c65d952036473de9a4adf0e94d222d880da56710ffd4c5d0c3511cfe4`
- `0003.witness.json` records event `48e651f2bb39a847a95ffdaafefd57991418fd83c260643cf695e55d9fc32cc6`
- `0003.returned.json` `48e651f2bb39a847a95ffdaafefd57991418fd83c260643cf695e55d9fc32cc6`
- `count.py` before tamper `a462cd0fc8d967065c00e2f7f162cb480e7d919d299fa5c03af46ba002679133` (87 bytes)
- `count.py` after tamper `470e2654c4289c25f63b198189fd63c5fe25a418eda01c989976f3f73659e7bd`

Tests. Relocated copy, not the shared checkout: 28 tests, 27 ok, 1 skipped, 82.029s. `python -B tests\test_clerk.py -v`. The skip is `test_symlink_output_refused_or_skipped`, WinError 1314. It is not a pass. Log: `labs/clerk-handoff-pass02/evidence/tests.pass02.txt`.

Demo. The same relocated copy printed `demo ok` and exited 0. Seventeen processes. Assignee inbox listed `demo-0001` queued; the reviewer inbox did not. Claim issued a token; a second claim and a claim as `colab` exited 2. A scripted process wrote `count.py`. Return recorded delivery `d-1` and the witness. The reviewer inbox showed that file's sha256. A fresh verify exited 0 with `chain ok` and `states queued claimed returned`. After the file was edited, show, the reviewer inbox, and verify reported `artifact changed`; verify exited 1.

Verified. Pack 05.02 inputs matched `evidence/pack05.02/source-manifest.tsv` before the edit (8 files, `input_bad 0`). The first lab manifest still matches its six unchanged files; `clerk.py`, `README.md`, and `tests/test_clerk.py` are the intended differences and are pinned by the new manifest. The before-copy of `clerk.py` is still `b75b6d0f5afc6d901d183739817ca5b0bfba8d1b1ddda2fc5bf67f50e5e24eab`. Git was read and not written. HEAD stayed `54274e698dde1c6cbd5e25177395c62c2a2c645a`. This correction did not edit pass01, app, the worker bridge, SoF, 05.03, 06.06, or 06.01 through 06.04.

Claimed as limits, not as test results. The witness catches an isolated missing or changed half of the returned pair. It does not catch a rewrite of both halves that still agrees, a rewrite of the whole store, or deletion of both files back to a claimed prefix. `--as` and the token are labels. `release` and `routed_by` are recorded text. Link checks do not stop a malicious same-user race. This machine did not create a symlink.

One bounded next step. Claude's independent review on 06.04.md, then Codex Prime accepts this return or asks for one bounded correction.

## Review — Codex Prime
PENDING.
