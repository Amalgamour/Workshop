#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""menu.py — face 03 from the sections on face 01.

Law 0003. A selection does not execute a command and does not permit.
The link form is the one already on 0003.operate face 03.
Optional faces are 02, 04, and 08. An absent one is omitted.
Face 01 is required. A missing face 01 is a finding.
"""
# ## notes
# born: 2026-10-14
# source: grok-prime, law band 0000-0100
# who: grok-prime

from __future__ import annotations

import re
import sys
import tempfile
from pathlib import Path

from face import EM, die, make_new, normalize, refuse_kernel_write

OPTIONAL = ("02", "04", "08")
WHY = "The job of the menu. A selection does not permit."
CITE = "3.5"


def face_paths(page: Path, number: str) -> list[Path]:
    found = [
        path for path in page.glob(f"{number}.*.draft.md")
        if path.is_file() and re.fullmatch(rf"{number}\.\d{{3}}\.draft\.md", path.name)
    ]
    seat = page / f"{number}.md"
    if seat.is_file():
        found.append(seat)
    if len(found) > 1 and sum(path.suffix == ".md" and ".draft." not in path.name for path in found) == 0:
        die("one draft is open")
    drafts = [path for path in found if ".draft." in path.name]
    if len(drafts) > 1:
        die("one draft is open")
    return found


def face_file(page: Path, number: str) -> Path | None:
    found = face_paths(page, number)
    drafts = [path for path in found if ".draft." in path.name]
    if drafts:
        return drafts[0]
    return found[0] if found else None


def titles_of(path: Path) -> list[str]:
    text = normalize(path.read_bytes())
    titles = []
    for line in text.splitlines():
        if not line.startswith("## "):
            continue
        title = line[3:].strip()
        if title.lower().startswith("note"):
            continue
        titles.append(title)
    return titles


def anchor(title: str) -> str:
    return re.sub(r"[^a-z0-9]+", "-", title.lower()).strip("-")


def menu_body(page: Path) -> str:
    source = face_file(page, "01")
    if source is None:
        die("finding: required face 01 is missing")
    titles = titles_of(source)
    if not titles:
        die("finding: face 01 has no section")
    optional = []
    for number in OPTIONAL:
        path = face_file(page, number)
        if path is not None:
            optional.append((number, path, set(titles_of(path))))
    blocks = []
    for title in titles:
        links = [f"[01 {EM} {title}]({source.name}#{anchor(title)})"]
        for number, path, have in optional:
            if title in have:
                links.append(f"[{number} {EM} {title}]({path.name}#{anchor(title)})")
        blocks.append(f"## {title}\n\nMenu: {'; '.join(links)}.\n\n")
    return "".join(blocks)


def make_menu(page: Path, who: str = "grok-prime") -> Path:
    refuse_kernel_write(page)
    if not page.is_dir():
        die("page folder is missing")
    return make_new(page, "03", who, WHY, CITE, menu_body(page))


def check(ok: bool, name: str) -> None:
    if not ok:
        die(f"test failed: {name}")


def cmd_test() -> None:
    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp)
        page = root / "10.workshop" / "10.10.work" / "10.10.11.solo-kernel" / "0609.trial"
        page.mkdir(parents=True)
        (page / "01.md").write_text(
            "# 01\n\nversion: 001\nwhy: Template.\n\n## Job\n\nOne.\n\n## Selection\n\nTwo.\n\n## Note\n\nSkip.\n",
            encoding="utf-8",
        )
        (page / "02.md").write_text(
            "# 02\n\n## Job\n\nCard.\n",
            encoding="utf-8",
        )
        (page / "06.md").write_text(
            "# 06\n\n## Job\n\nUNIQUE face 06 menu stays off.\n",
            encoding="utf-8",
        )
        (page / "07.md").write_text(
            "# 07\n\n## Job\n\nFace 07 stays off the menu.\n",
            encoding="utf-8",
        )
        made = make_menu(page)
        text = made.read_text(encoding="utf-8")
        check(made.name == "03.001.draft.md", "menu name")
        check("## Job" in text and "## Selection" in text, "sections")
        check("## Note" not in text, "note skipped")
        check(f"[01 {EM} Job](01.md#job)" in text, "face 01 job")
        check(f"[02 {EM} Job](02.md#job)" in text, "face 02 job")
        check("02.md#selection" not in text, "absent section omitted")
        check("06.md" not in text and "07.md" not in text, "06 and 07 omitted")
        check("UNIQUE face 06" not in text, "face 06 body stays off")
        check("http" not in text and "owner: kernel-only" not in text, "no invented route")
        check("state: draft" in text, "state draft")
        check(WHY in text, "menu why")
        try:
            make_menu(page)
            die("test opened a second menu")
        except SystemExit as exc:
            check("one draft is open" in str(exc), "second menu stops")
        empty = page.parent / "0610.empty"
        empty.mkdir()
        try:
            make_menu(empty)
            die("test wrote a menu without face 01")
        except SystemExit as exc:
            check("required face 01 is missing" in str(exc), "missing 01 is a finding")
        blocked = root / "00.00.00.kernel.draft" / "00.00.01.law" / "0003.operate"
        blocked.mkdir(parents=True)
        (blocked / "01.md").write_text("# 01\n\n## Job\n\nNo.\n", encoding="utf-8")
        try:
            make_menu(blocked)
            die("test wrote the template")
        except SystemExit as exc:
            check("template kernel is not edited" in str(exc), "kernel write stops")
    print("test: pass")


def main(argv: list[str] | None = None) -> None:
    args = list(sys.argv[1:] if argv is None else argv)
    if not args:
        die("use test, or make PAGE")
    if args[0] == "test":
        cmd_test()
        return
    if args[0] == "make":
        if len(args) < 2:
            die("make PAGE")
        made = make_menu(Path(args[1]))
        print(f"draft: {made.name}")
        return
    die("use test, or make PAGE")


if __name__ == "__main__":
    main()
