#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""menu.py — face 03 lists sections.

Law 0003. A selection does not execute a command and does not permit.
Face 01 holds the sections. It does not hold the menu.
Face 02 holds the schema. Each schema section also needs face 01 and face 04.
Face 04 holds the why and any further detail.
A heading is a lookup for the compute. A heading stays off the menu.
A heading that is not a section stays off the menu.
Face 03 is the header and the section lines. It does not need a heading.
A large menu divided into sections is a later job.
Face 08 is linked only when it shares a section. Faces 05, 06, and 07 stay off.
"""
# ## notes
# born: 2026-10-14
# source: grok-prime, law band 0000-0100
# who: grok-prime

from __future__ import annotations

import re
import sys
import tempfile
from pathlib import Path

from face import EM, die, make_new, normalize, refuse_kernel_write

OPTIONAL = ("02", "04", "08")
WHY = "The job of the menu. A selection does not permit."
CITE = "3.5"


def face_paths(page: Path, number: str) -> list[Path]:
    found = [
        path for path in page.glob(f"{number}.*.draft.md")
        if path.is_file() and re.fullmatch(rf"{number}\.\d{{3}}\.draft\.md", path.name)
    ]
    seat = page / f"{number}.md"
    if seat.is_file():
        found.append(seat)
    if len(found) > 1 and sum(path.suffix == ".md" and ".draft." not in path.name for path in found) == 0:
        die("one draft is open")
    drafts = [path for path in found if ".draft." in path.name]
    if len(drafts) > 1:
        die("one draft is open")
    return found


def face_file(page: Path, number: str) -> Path | None:
    found = face_paths(page, number)
    drafts = [path for path in found if ".draft." in path.name]
    if drafts:
        return drafts[0]
    return found[0] if found else None


def titles_of(path: Path) -> list[str]:
    text = normalize(path.read_bytes())
    titles = []
    for line in text.splitlines():
        if not line.startswith("## "):
            continue
        title = line[3:].strip()
        if title.lower().startswith("note"):
            continue
        titles.append(title)
    return titles


def anchor(title: str) -> str:
    return re.sub(r"[^a-z0-9]+", "-", title.lower()).strip("-")


def menu_titles(page: Path) -> list[str]:
    source = face_file(page, "01")
    if source is None:
        die("finding: required face 01 is missing")
    first = titles_of(source)
    if not first:
        die("finding: face 01 has no section")
    for line in source.read_text(encoding="utf-8").splitlines():
        if line.startswith("Menu:"):
            die("the menu is face 03")
    on_first = set(first)
    two = face_file(page, "02")
    four = face_file(page, "04")
    on_four = set(titles_of(four)) if four is not None else set()
    if two is not None:
        for title in titles_of(two):
            if title not in on_first:
                die("schema needs a section on face 01")
            if title not in on_four:
                die("schema needs a section on face 04")
    return list(first)


def menu_body(page: Path) -> str:
    titles = menu_titles(page)
    present = []
    for number in ("01", *OPTIONAL):
        path = face_file(page, number)
        if path is not None:
            present.append((number, path, set(titles_of(path))))
    lines = []
    for title in titles:
        links = []
        for number, path, have in present:
            if title in have:
                links.append(f"[{number} {EM} {title}]({path.name}#{anchor(title)})")
        lines.append(f"Menu: {'; '.join(links)}.")
    return "\n\n".join(lines) + "\n"


def check_built(page: Path) -> None:
    """The constructed page has sections on 01, schema on 02, why on 04, menu on 03."""
    source = face_file(page, "01")
    if source is None:
        die("finding: required face 01 is missing")
    for line in source.read_text(encoding="utf-8").splitlines():
        if line.startswith("Menu:"):
            die("the menu is face 03")
    menu = face_file(page, "03")
    if menu is None:
        die("finding: face 03 is missing")
    text = menu.read_text(encoding="utf-8")
    if "state: draft" not in text or "Authorization: draft" not in text:
        die("menu is not a draft")
    if not text.startswith("# 03\n"):
        die("menu header is missing")
    if any(line.startswith("## ") for line in text.splitlines()):
        die("a heading does not belong on the menu")
    sections = set(titles_of(source))
    for title in re.findall(rf"\[\d{{2}} {re.escape(EM)} ([^\]]+)\]", text):
        if title not in sections:
            die(f"menu lists {title}. a heading is not a section")
    for title in titles_of(source):
        link = f"[01 {EM} {title}]({source.name}#{anchor(title)})"
        if link not in text:
            die(f"menu misses 01 {title}")
    two = face_file(page, "02")
    four = face_file(page, "04")
    if two is None:
        return
    if four is None:
        die("schema needs a section on face 04")
    for title in titles_of(two):
        if title not in titles_of(source):
            die("schema needs a section on face 01")
        if title not in titles_of(four):
            die("schema needs a section on face 04")
        slug = anchor(title)
        for number, path in (("01", source), ("02", two), ("04", four)):
            link = f"[{number} {EM} {title}]({path.name}#{slug})"
            if link not in text:
                die(f"menu misses {number} {title}")


def make_menu(page: Path, who: str = "grok-prime") -> Path:
    refuse_kernel_write(page)
    if not page.is_dir():
        die("page folder is missing")
    return make_new(page, "03", who, WHY, CITE, menu_body(page))


def check_journey(page: Path) -> None:
    """The menu sections look up headings on the faces they name. Each face keeps its stamp."""
    check_built(page)
    menu = face_file(page, "03")
    text = menu.read_text(encoding="utf-8")
    found = re.findall(r"\]\(([^)#]+)#([^)]+)\)", text)
    if not found:
        die("menu has no section")
    for name, slug in found:
        target = page / name
        if not target.is_file():
            die(f"menu link {name} is missing")
        have = {anchor(title) for title in titles_of(target)}
        if slug not in have:
            die(f"menu anchor {slug} is missing on {name}")
    for number in ("01", "02", "03", "04", "06"):
        path = face_file(page, number)
        if path is None:
            die(f"finding: face {number} is missing")
        face = path.read_text(encoding="utf-8")
        if not face.startswith(f"# {number}\n") or "Authorization: draft" not in face:
            die(f"face {number} header has no stamp")


def check(ok: bool, name: str) -> None:
    if not ok:
        die(f"test failed: {name}")


def cmd_test() -> None:
    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp)
        page = root / "10.workshop" / "10.10.work" / "10.10.11.solo-kernel" / "0609.trial"
        page.mkdir(parents=True)
        (page / "01.md").write_text(
            "# 01\n\nversion: 001\nwhy: Template.\n\n## Job\n\nOne.\n\n## Selection\n\nTwo.\n\n## Note\n\nSkip.\n",
            encoding="utf-8",
        )
        (page / "02.md").write_text(
            "# 02\n\n## Job\n\nCard.\n",
            encoding="utf-8",
        )
        (page / "04.md").write_text(
            "# 04\n\n## Job\n\nWhy: because the section needs a person read.\n\n"
            "Body: The extra detail sits here.\n\n## Detail\n\nOnly on this face.\n",
            encoding="utf-8",
        )
        (page / "06.md").write_text(
            "# 06\n\n## Job\n\nUNIQUE face 06 menu stays off.\n",
            encoding="utf-8",
        )
        (page / "07.md").write_text(
            "# 07\n\n## Job\n\nFace 07 stays off the menu.\n",
            encoding="utf-8",
        )
        made = make_menu(page)
        text = made.read_text(encoding="utf-8")
        check(made.name == "03.001.draft.md", "menu name")
        check(text.startswith("# 03\n") and "Authorization: draft" in text, "menu stamp")
        check("\n## " not in text, "headings stay off")
        check("## Note" not in text, "note skipped")
        check(f"[01 {EM} Job](01.md#job)" in text, "face 01 job")
        check(f"[01 {EM} Selection](01.md#selection)" in text, "section selection")
        check(f"[02 {EM} Job](02.md#job)" in text, "face 02 job")
        check(f"[04 {EM} Job](04.md#job)" in text, "face 04 job")
        check(f"[04 {EM} Detail]" not in text and "#detail" not in text, "face 04 heading stays off")
        check("02.md#selection" not in text, "absent section omitted")
        check("Menu:" not in (page / "01.md").read_text(encoding="utf-8"), "face 01 has no menu")
        check("06.md" not in text and "07.md" not in text, "06 and 07 omitted")
        check("UNIQUE face 06" not in text, "face 06 body stays off")
        check("http" not in text and "owner: kernel-only" not in text, "no invented route")
        check("state: draft" in text, "state draft")
        check(WHY in text, "menu why")
        try:
            make_menu(page)
            die("test opened a second menu")
        except SystemExit as exc:
            check("one draft is open" in str(exc), "second menu stops")
        empty = page.parent / "0610.empty"
        empty.mkdir()
        try:
            make_menu(empty)
            die("test wrote a menu without face 01")
        except SystemExit as exc:
            check("required face 01 is missing" in str(exc), "missing 01 is a finding")
        blocked = root / "00.00.00.kernel.draft" / "00.00.01.law" / "0003.operate"
        blocked.mkdir(parents=True)
        (blocked / "01.md").write_text("# 01\n\n## Job\n\nNo.\n", encoding="utf-8")
        try:
            make_menu(blocked)
            die("test wrote the template")
        except SystemExit as exc:
            check("template kernel is not edited" in str(exc), "kernel write stops")
        bare = page.parent / "0611.schema"
        bare.mkdir()
        (bare / "01.md").write_text("# 01\n\n## Job\n\nOne.\n", encoding="utf-8")
        (bare / "02.md").write_text("# 02\n\n## Schema\n\nThe list.\n", encoding="utf-8")
        try:
            make_menu(bare)
            die("test built a schema with no face 01 section")
        except SystemExit as exc:
            check("schema needs a section on face 01" in str(exc), "schema needs 01")
        (bare / "01.md").write_text("# 01\n\n## Schema\n\nThe need.\n", encoding="utf-8")
        try:
            make_menu(bare)
            die("test built a schema with no face 04")
        except SystemExit as exc:
            check("schema needs a section on face 04" in str(exc), "schema needs 04")
        (bare / "04.md").write_text(
            "# 04\n\n## Schema\n\nWhy: because the list must stay the same.\n",
            encoding="utf-8",
        )
        built = make_menu(bare)
        built_text = built.read_text(encoding="utf-8")
        check(f"[01 {EM} Schema](01.md#schema)" in built_text, "schema on 01")
        check(f"[02 {EM} Schema](02.md#schema)" in built_text, "schema on 02")
        check(f"[04 {EM} Schema](04.md#schema)" in built_text, "schema on 04")
        check("\n## " not in built_text, "schema heading stays off the menu")
        check_built(bare)
        menu_face = page.parent / "0612.menu"
        menu_face.mkdir()
        (menu_face / "01.md").write_text(
            "# 01\n\n## Job\n\nMenu: [01 — Job](01.md#job).\n",
            encoding="utf-8",
        )
        try:
            make_menu(menu_face)
            die("test accepted a menu on face 01")
        except SystemExit as exc:
            check("the menu is face 03" in str(exc), "menu stays off face 01")
    root = Path(__file__).resolve().parents[1]
    operate = root / "sample" / "00.00.00.syntax" / "0003.operate"
    journal = root / "use" / "10.ned" / "10.10.cabin" / "10.10.10.journal"
    checklist = next((path for path in journal.iterdir() if path.name.endswith(".checklist")), None)
    if not operate.is_dir() or checklist is None:
        die("constructed pages are missing")
    check_journey(operate)
    check_journey(checklist)
    schema = face_file(checklist, "02").read_text(encoding="utf-8")
    order = [schema.find(word) for word in ("post", "tree base", "buoy", "light")]
    check(all(spot >= 0 for spot in order) and order == sorted(order), "checklist order")
    print("test: pass")


def main(argv: list[str] | None = None) -> None:
    args = list(sys.argv[1:] if argv is None else argv)
    if not args:
        die("use test, or make PAGE")
    if args[0] == "test":
        cmd_test()
        return
    if args[0] == "make":
        if len(args) < 2:
            die("make PAGE")
        made = make_menu(Path(args[1]))
        print(f"draft: {made.name}")
        return
    die("use test, or make PAGE")


if __name__ == "__main__":
    main()
